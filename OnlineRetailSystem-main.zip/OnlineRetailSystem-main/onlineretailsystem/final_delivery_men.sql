-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: final
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `delivery_men`
--

DROP TABLE IF EXISTS `delivery_men`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_men` (
  `Delivery_ID` int NOT NULL,
  `Deliveryman_Name` varchar(50) NOT NULL,
  `Order_Id` int DEFAULT NULL,
  PRIMARY KEY (`Delivery_ID`),
  KEY `delivery_men_ibfk_1` (`Order_Id`),
  CONSTRAINT `delivery_men_ibfk_1` FOREIGN KEY (`Order_Id`) REFERENCES `orders` (`Order_Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_men`
--

LOCK TABLES `delivery_men` WRITE;
/*!40000 ALTER TABLE `delivery_men` DISABLE KEYS */;
INSERT INTO `delivery_men` VALUES (7,'Bernie',7),(8,'Hastings',8),(9,'Rochette',9),(11,'Rodina',11),(12,'Coreen',12),(15,'Katheryn',15),(16,'Kylen',16),(18,'Geoff',18),(22,'Burnard',22),(25,'Crystal',25),(27,'Didi',27),(28,'Rosetta',28),(30,'Skell',30),(31,'Emily',31),(32,'Vallie',32),(34,'Arly',34),(35,'Anatol',35),(36,'Kirsteni',36),(37,'Marjorie',37),(38,'Tadio',38),(39,'Hermine',39),(41,'Pearl',41),(43,'Felita',43),(44,'Tatiana',44),(45,'Dana',45),(46,'Shurwood',46),(47,'Jan',47),(48,'Tybie',48),(49,'Selene',49),(51,'Maxie',51),(52,'Sascha',52),(53,'Wynne',53),(54,'Jillian',54),(55,'Hester',55),(58,'Lula',58),(60,'Cristiano',60),(61,'Humfrey',61),(62,'Kelsey',62),(64,'Nat',64),(65,'Ivett',65),(66,'Justinn',66),(67,'Becka',67),(70,'Hakeem',70),(72,'Moise',72),(74,'Benita',74),(75,'Ynes',75),(77,'Katey',77),(80,'Elvyn',80),(81,'Ozzie',81),(82,'Evaleen',82),(84,'Abagail',84),(85,'Jermaine',85),(86,'Donetta',86),(87,'Flori',87),(89,'Belinda',89),(90,'Ignazio',90),(91,'Delilah',91),(92,'Tabor',92),(93,'Thaine',93),(94,'Craggy',94),(95,'Emelia',95),(99,'Alleen',99),(100,'alok',9);
/*!40000 ALTER TABLE `delivery_men` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-24 18:27:37
