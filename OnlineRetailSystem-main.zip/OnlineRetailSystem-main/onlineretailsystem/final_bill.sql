-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: final
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill` (
  `Bill_Id` int NOT NULL,
  `Amount` int DEFAULT NULL,
  `Payment_Mode` text,
  PRIMARY KEY (`Bill_Id`),
  KEY `billid_idx` (`Bill_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES (1,1456,'online'),(2,20000,'Praesent blandit.'),(3,2822,'k'),(4,64,'Proin at turpis a pede posuere nonummy.'),(5,100,'Mauris enim leo, rhoncus sed, vestibulum sit amet, cursus id, turpis. Integer aliquet, massa id lobortis convallis, tortor risus dapibus augue, vel accumsan tellus nisi eu orci.'),(6,216,'Duis mattis egestas metus.'),(7,343,'Fusce lacus purus, aliquet at, feugiat non, pretium quis, lectus. Suspendisse potenti.'),(8,512,'Pellentesque eget nunc. Donec quis orci eget orci vehicula condimentum. Curabitur in libero ut massa volutpat convallis.'),(9,729,'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat.'),(10,1000,'Curabitur gravida nisi at nibh. In hac habitasse platea dictumst.'),(11,100,'Etiam justo. Etiam pretium iaculis justo. In hac habitasse platea dictumst.'),(12,1728,'Sed ante. Vivamus tortor.'),(13,2197,'Pellentesque viverra pede ac diam. Cras pellentesque volutpat dui. Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc.'),(14,2744,'Ut at dolor quis odio consequat varius. Integer ac leo.'),(15,3375,'Fusce posuere felis sed lacus.'),(16,4096,'Suspendisse potenti. Cras in purus eu magna vulputate luctus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.'),(17,4913,'Maecenas tincidunt lacus at velit. Vivamus vel nulla eget eros elementum pellentesque. Quisque porta volutpat erat.'),(18,5832,'Mauris sit amet eros. Suspendisse accumsan tortor quis turpis.'),(19,6859,'Ut at dolor quis odio consequat varius. Integer ac leo. Pellentesque ultrices mattis odio.'),(20,8000,'In quis justo. Maecenas rhoncus aliquam lacus. Morbi quis tortor id nulla ultrices aliquet.'),(21,9261,'Morbi sem mauris, laoreet ut, rhoncus aliquet, pulvinar sed, nisl. Nunc rhoncus dui vel sem.'),(22,10648,'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis. Fusce posuere felis sed lacus.'),(23,12167,'In congue. Etiam justo. Etiam pretium iaculis justo.'),(24,13824,'Praesent blandit. Nam nulla.'),(25,956,'COD'),(26,17576,'Vivamus tortor.'),(27,19683,'Aenean lectus. Pellentesque eget nunc.'),(28,21952,'Aliquam quis turpis eget elit sodales scelerisque.'),(29,24389,'Etiam vel augue. Vestibulum rutrum rutrum neque. Aenean auctor gravida sem.'),(30,27000,'Vivamus in felis eu sapien cursus vestibulum. Proin eu mi.'),(31,29791,'Suspendisse potenti. Cras in purus eu magna vulputate luctus.'),(32,32768,'Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros. Vestibulum ac est lacinia nisi venenatis tristique.'),(33,35937,'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),(34,39304,'Mauris lacinia sapien quis libero.'),(35,42875,'Morbi vel lectus in quam fringilla rhoncus.'),(36,46656,'Vivamus tortor. Duis mattis egestas metus.'),(37,50653,'Vestibulum ac est lacinia nisi venenatis tristique.'),(38,54872,'Morbi ut odio.'),(39,59319,'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam. Nam tristique tortor eu pede.'),(40,64000,'Integer tincidunt ante vel ipsum.'),(41,68921,'Quisque id justo sit amet sapien dignissim vestibulum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est.'),(42,74088,'Nunc rhoncus dui vel sem.'),(43,79507,'Ut at dolor quis odio consequat varius.'),(44,85184,'Morbi quis tortor id nulla ultrices aliquet. Maecenas leo odio, condimentum id, luctus nec, molestie sed, justo.'),(45,91125,'Integer tincidunt ante vel ipsum.'),(46,97336,'Etiam faucibus cursus urna. Ut tellus.'),(47,103823,'Sed ante.'),(48,110592,'Suspendisse potenti. Nullam porttitor lacus at turpis.'),(49,117649,'Morbi a ipsum. Integer a nibh. In quis justo.'),(51,132651,'Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis.'),(52,140608,'Morbi non lectus. Aliquam sit amet diam in magna bibendum imperdiet. Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.'),(53,148877,'Suspendisse accumsan tortor quis turpis.'),(54,157464,'Nulla tellus. In sagittis dui vel nisl.'),(55,166375,'Duis at velit eu est congue elementum. In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante.'),(56,175616,'Vestibulum ac est lacinia nisi venenatis tristique.'),(57,185193,'Etiam vel augue.'),(58,195112,'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.'),(59,205379,'Curabitur in libero ut massa volutpat convallis.'),(60,216000,'Proin at turpis a pede posuere nonummy. Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.'),(61,226981,'Cras pellentesque volutpat dui. Maecenas tristique, est et tempus semper, est quam pharetra magna, ac consequat metus sapien ut nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Mauris viverra diam vitae quam.'),(62,238328,'Phasellus sit amet erat.'),(63,250047,'Vivamus in felis eu sapien cursus vestibulum.'),(64,262144,'Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla.'),(65,274625,'Nulla ut erat id mauris vulputate elementum.'),(66,287496,'Suspendisse potenti. Cras in purus eu magna vulputate luctus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.'),(67,100,'Nullam molestie nibh in lectus.'),(68,314432,'Morbi odio odio, elementum eu, interdum eu, tincidunt in, leo.'),(69,328509,'Morbi a ipsum. Integer a nibh. In quis justo.'),(70,343000,'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat.'),(71,357911,'Sed sagittis. Nam congue, risus semper porta volutpat, quam pede lobortis ligula, sit amet eleifend pede libero quis orci. Nullam molestie nibh in lectus.'),(72,373248,'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla dapibus dolor vel est. Donec odio justo, sollicitudin ut, suscipit a, feugiat et, eros.'),(73,389017,'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque. Duis bibendum.'),(74,405224,'Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.'),(75,421875,'Nulla justo. Aliquam quis turpis eget elit sodales scelerisque. Mauris sit amet eros.'),(76,438976,'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec pharetra, magna vestibulum aliquet ultrices, erat tortor sollicitudin mi, sit amet lobortis sapien sapien non mi. Integer ac neque.'),(77,456533,'Proin eu mi.'),(78,474552,'Aenean auctor gravida sem. Praesent id massa id nisl venenatis lacinia.'),(79,493039,'Nullam orci pede, venenatis non, sodales sed, tincidunt eu, felis.'),(80,512000,'Curabitur convallis. Duis consequat dui nec nisi volutpat eleifend. Donec ut dolor.'),(81,531441,'Integer a nibh.'),(82,551368,'Proin at turpis a pede posuere nonummy. Integer non velit. Donec diam neque, vestibulum eget, vulputate ut, ultrices vel, augue.'),(83,571787,'Mauris sit amet eros. Suspendisse accumsan tortor quis turpis. Sed ante.'),(84,592704,'Praesent blandit lacinia erat.'),(85,614125,'Etiam justo. Etiam pretium iaculis justo.'),(86,636056,'Duis mattis egestas metus. Aenean fermentum.'),(87,658503,'Etiam pretium iaculis justo.'),(88,681472,'Cras in purus eu magna vulputate luctus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.'),(89,704969,'In eleifend quam a odio.'),(90,729000,'Aenean lectus. Pellentesque eget nunc.'),(91,753571,'Integer tincidunt ante vel ipsum. Praesent blandit lacinia erat.'),(92,778688,'Duis at velit eu est congue elementum. In hac habitasse platea dictumst.'),(93,804357,'Nullam varius. Nulla facilisi.'),(94,830584,'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.'),(95,857375,'Etiam justo. Etiam pretium iaculis justo. In hac habitasse platea dictumst.'),(96,884736,'Nulla tellus. In sagittis dui vel nisl. Duis ac nibh.'),(97,912673,'In hac habitasse platea dictumst. Maecenas ut massa quis augue luctus tincidunt.'),(98,941192,'Quisque arcu libero, rutrum ac, lobortis vel, dapibus at, diam. Nam tristique tortor eu pede.'),(99,100,'Nulla justo. Aliquam quis turpis eget elit sodales scelerisque.');
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-24 18:27:37
