-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: final
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `Admin_ID` int NOT NULL,
  `User_Name` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Category_id` int DEFAULT NULL,
  `Product_id` int DEFAULT NULL,
  `Delivery_ID` int DEFAULT NULL,
  PRIMARY KEY (`Admin_ID`),
  KEY `adminid_idx` (`Admin_ID`),
  KEY `admin_ibfk_1` (`Category_id`),
  KEY `admin_ibfk_2` (`Product_id`),
  KEY `admin_ibfk_3` (`Delivery_ID`),
  CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`Category_id`) REFERENCES `category` (`Category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `admin_ibfk_2` FOREIGN KEY (`Product_id`) REFERENCES `product_catalog` (`Product_Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `admin_ibfk_3` FOREIGN KEY (`Delivery_ID`) REFERENCES `delivery_men` (`Delivery_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (7,'hkmicicki6','tYIybSr3m',7,7,7),(8,'mscruton7','6A1jYBmM1',8,8,8),(9,'fdongate8','QAm6vZbYG2vq',9,9,9),(11,'mboococka','EGl5JOLTS',11,11,11),(12,'bknellb','NHhC200',12,12,12),(15,'mmacake','uDfr3LYPG',15,15,15),(16,'bsearightf','9FRidim1Gln8',16,16,16),(18,'ngrocotth','RXfemhOqmSw',18,18,18),(22,'ramorinel','84zVxM84',22,22,22),(25,'bmaulkino','lngZXhq',25,25,25),(27,'lbeebyq','QZPzxd',27,27,27),(28,'cosgorbyr','WDyMpIbJxB',28,28,28),(30,'gdebrettt','WtvwFRw',30,30,30),(31,'llondingu','jKlaoMwR',31,31,31),(32,'scrannachv','LDdwAD',32,32,32),(34,'mproswellx','vXF1w3A',34,34,34),(35,'akerreyy','K78pP639O',35,35,35),(36,'jcuniffez','1uD6AHTh3d8S',36,36,36),(37,'mclemensen10','1rfWcRI',37,37,37),(38,'iivanshintsev11','yg7aKXLb6',38,38,38),(39,'ishatliffe12','OsYfGRhM',39,39,39),(41,'ifilyushkin14','5r0rOV6',41,41,41),(43,'tdollman16','himp1BqXdf',43,43,43),(44,'cquilleash17','mdCbW1J',44,44,44),(45,'hcarnegy18','6sKUzJNplEGd',45,45,45),(46,'bree19','q2YicTgEqD',46,46,46),(47,'mmecchi1a','tpRuHVL',47,47,47),(48,'ssolman1b','TAyaAdv1Q',48,48,48),(49,'leckly1c','c5MiwFUWxztO',49,49,49),(51,'lderrico1e','Hl03RWqXeyTN',51,51,51),(52,'tiacobucci1f','ewPmWsXwOKJY',52,52,52),(53,'mmeysham1g','gI71MI9B',53,53,53),(54,'mbohlingolsen1h','hKDeYFDowGl0',54,54,54),(55,'tbartholomieu1i','xdwIoAS2',55,55,55),(58,'jtandey1l','smJ5EtgI9A',58,58,58),(60,'adoxey1n','hSq6jHXoc1',60,60,60),(61,'bsinkins1o','HE3bH5k',61,61,61),(62,'eisaksson1p','S4H3RJJuBFl',62,62,62),(64,'ppikesley1r','omZtuIFasudo',64,64,64),(65,'mlambe1s','fGfSQV1',65,65,65),(66,'bwager1t','m7t7GP',66,66,66),(67,'sbaggaley1u','i6nZJtH3xnRy',67,67,67),(70,'hdunridge1x','HaKx5a8XhU',70,70,70),(72,'mgres1z','8gjAKf32x3zx',72,72,72),(74,'chellwig21','s6LSvu0cTc3',74,74,74),(75,'alurcock22','1tNmuF9OFFF',75,75,75),(77,'ttebald24','AtQSwzX',77,77,77),(80,'tjumont27','OId3vBM2yx',80,80,80),(81,'lshortan28','yOMVFNysLj',81,81,81),(82,'dravel29','maX4w0UbrUY',82,82,82),(84,'kdono2b','cfNDkZ',84,84,84),(85,'mgeorgiev2c','1YUIq6Wgk47',85,85,85),(86,'dgillinghams2d','Ye8gCoWf',86,86,86),(87,'jeddicott2e','vP90qGHuJO',87,87,87),(89,'dbaythrop2g','b6qtPeHC6',89,89,89),(90,'zurian2h','Eh9Bx3I9dcc5',90,90,90),(91,'hthorald2i','L7qY0Z',91,91,91),(92,'gmoulder2j','HgPpTlPn',92,92,92),(93,'gbackhurst2k','NNAqFM4',93,93,93),(94,'rwoollcott2l','fpcMtEX4eBsU',94,94,94),(95,'ymertsching2m','0xs2pg',95,95,95),(99,'jjarrel2q','WfQbGUDib',99,99,99);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-24 18:27:37
