-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: final
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `Customer_id` int NOT NULL,
  `Customer_firstName` varchar(50) NOT NULL,
  `Customer_lastName` varchar(50) DEFAULT NULL,
  `Customer_Address` varchar(50) NOT NULL,
  `Customer_Phone_no` bigint NOT NULL,
  `Customer_Password` varchar(50) NOT NULL,
  `Customer_Email` varchar(50) NOT NULL,
  `Order_Id` int DEFAULT NULL,
  `Satus` tinyint(1) DEFAULT NULL,
  `Product_Id` int NOT NULL,
  PRIMARY KEY (`Customer_id`),
  KEY `firstname_idx` (`Customer_firstName`),
  KEY `fk_customer_orders_idx` (`Order_Id`),
  KEY `fk_customer_product_catalog_idx` (`Product_Id`),
  KEY `fk_customer_delivery_status_idx` (`Customer_id`),
  CONSTRAINT `fk_customer_delivery_status` FOREIGN KEY (`Customer_id`) REFERENCES `delivery_status` (`Customer_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_customer_orders` FOREIGN KEY (`Order_Id`) REFERENCES `orders` (`Order_Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_customer_product_catalog` FOREIGN KEY (`Product_Id`) REFERENCES `product_catalog` (`Product_Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (3,'Drashy','Sesodia','J-15',8882083572,'aqw','drashy21461@iiitd.ac.in',90,0,90),(25,'Jonah','Cosins','PO Box 93789',3685811264,'v1L222oB1wzQ','jcosinso@xing.com',25,0,25),(27,'Natalee','Perrone','Suite 7',8843396748,'WGQ6x9h6','nperroneq@digg.com',27,0,27),(31,'Paco','Whight','PO Box 41557',6700583376,'0nPrZWyFNc','pwhightu@delicious.com',31,0,31),(35,'Gae','Alcalde','Room 63',7115145657,'YCZUcQi0I','galcaldey@techcrunch.com',35,1,35),(37,'Isabel','Elson','Suite 37',2819913178,'gsgcMJ6A','ielson10@guardian.co.uk',37,0,37),(39,'Nicola','Colley','Room 314',8985588798,'yzJtVS3','ncolley12@dot.gov',39,1,39),(41,'Debbi','Daleman','PO Box 98088',4302642318,'V1IG6nnWt','ddaleman14@mit.edu',41,1,41),(43,'Christi','Thorbon','Suite 99',7129900672,'0CusiXK','cthorbon16@house.gov',43,1,43),(45,'Allyson','Stainer','Room 370',7849654927,'gGYLXm','astainer18@stumbleupon.com',45,1,45),(47,'Alyosha','Jaksic','PO Box 6754',3436197805,'hdctXzo565','ajaksic1a@huffingtonpost.com',47,0,47),(49,'Patrica','Claworth','PO Box 25513',3406875456,'5X8aHUuXY','pclaworth1c@yandex.ru',49,1,49),(51,'Enrichetta','Vaen','Apt 1116',1430487501,'ifXx2D','evaen1e@omniture.com',51,1,51),(53,'Abbye','Ingle','Room 564',8304123318,'jbdLBY2xQX','aingle1g@odnoklassniki.ru',53,1,53),(55,'Silvan','Syson','PO Box 7110',6891825389,'PGA8XSd5U','ssyson1i@nationalgeographic.com',55,0,55),(61,'Catherina','Peachman','Suite 48',2211238698,'wYBL0PygF','cpeachman1o@jiathis.com',61,0,61),(65,'Kirbie','Francillo','Apt 796',1943799092,'MOIU4boRR','kfrancillo1s@hibu.com',65,1,65),(67,'Ezechiel','Leyburn','7th Floor',1106792107,'a5idY97xbS','eleyburn1u@aol.com',67,1,67),(75,'Germain','Simnell','Room 1696',7592055571,'mWel4r4u84','gsimnell22@nationalgeographic.com',75,1,75),(77,'Sarita','Lago','Room 1475',2106601012,'gV2oOt','slago24@who.int',77,0,77),(81,'Carolan','Aldis','PO Box 21505',8092922050,'Xm0Ttw','caldis28@unblog.fr',81,0,81),(85,'Talbert','Samworth','Room 625',5314315413,'NCwaYfVqJsY','tsamworth2c@ycombinator.com',85,0,85),(87,'Oliy','Kenford','11th Floor',1179704113,'qNFQpPT5','okenford2e@whitehouse.gov',87,0,87),(89,'Ingaberg','Eyres','Apt 251',9960989514,'fztH1VK1','ieyres2g@indiatimes.com',89,0,89),(91,'Hermione','Duffan','Room 913',2229293771,'5mimAN2g','hduffan2i@creativecommons.org',91,0,91),(93,'Talya','Corss','17th Floor',3074421586,'RvkqmxTmQ','tcorss2k@dell.com',93,1,93),(95,'Forester','Ucchino','Room 452',6168140973,'RJZkTcri2Mg','fucchino2m@blog.com',95,1,95),(99,'Dasya','Trinder','Apt 1199',3390702396,'9KbzjURRX1','dtrinder2q@desdev.cn',99,0,99);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-24 18:27:37
