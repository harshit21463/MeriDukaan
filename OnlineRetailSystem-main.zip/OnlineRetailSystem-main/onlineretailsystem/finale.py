import mysql.connector as c
import random
con=c.connect(host="localhost",user="root",passwd="@Shlok1234",database="final")
con2=c.connect(host="localhost",user="root",passwd="@Shlok1234",database="final")
con3=c.connect(host="localhost",user="root",passwd="@Shlok1234")
cursor=con.cursor()
cursor2=con2.cursor()
cursor3=con3.cursor()

if con.is_connected():
    print("Yes Connected")
else:
    print("NO connection lost")

def signupAdmin(a,b,c,d,e,f):
    cursor.execute(f"SELECT EXISTS (SELECT * FROM admin WHERE Admin_ID = '{a}');")
    result = cursor.fetchone()[0]
    if(result==1):
        print("The Admin ID exits already\n")
    else:
        try:
            cursor.execute(f"INSERT INTO admin (Admin_ID, User_Name,Password,Category_id, Product_id, Delivery_ID) VALUES ('{a}','{b}','{c}','{d}','{e}','{f}')")
            con.commit()
        except:
            print("Product_id/Category_id/Delivery_id are not present in their tables\n")
        
        print("SIGN UP COMPLETED\n")

def query():
    # cursor.execute("SELECT * FROM admin")
    # db=cursor.fetchall()
    # for j in db:
    #     print(j)
    print("\n")

def addcategory(Category_id,Category_Name,Description):
    cursor.execute(f"SELECT EXISTS (SELECT * FROM category WHERE Category_id='{Category_id}')")
    result = cursor.fetchone()[0]
    if(result==1):
        print("Category already exist\n")
    else:
        cursor.execute(f"INSERT INTO category (Category_id,Category_Name,Description) VALUES ('{Category_id}','{Category_Name}','{Description}')")
        print("Category Added\n")
        con.commit()

def addproduct(Product_id,Product_Name,Description,Quantity,Price):
    cursor.execute(f"SELECT EXISTS (SELECT * FROM product_catalog WHERE Product_id='{Product_id}')")
    result = cursor.fetchone()[0]
    if(result==1):
        print("Product already exist\n")
    else:
        cursor.execute(f"INSERT INTO product_catalog (Product_id,Product_Name,Description,Quantity,Price) VALUES ('{Product_id}','{Product_Name}','{Description}','{Quantity}','{Price}')")
        print("product added\n")
        con.commit()

def adddelivery(Delivery_ID,Deliveryman_Name,Order_Id):
    cursor.execute(f"SELECT EXISTS (SELECT * FROM delivery_men WHERE Delivery_ID='{Delivery_ID}')")
    result = cursor.fetchone()[0]
    if(result==1):
        print("Delivery ID already exist\n")
    else:
        try:
            cursor.execute(f"INSERT INTO delivery_men (Delivery_ID,Deliveryman_Name,Order_Id) VALUES ('{Delivery_ID}','{Deliveryman_Name}','{Order_Id}')")
            print("Delivery Man Details added\n")
            con.commit()
        except:
            print("Order ID Not exist\n")

def signupCustomer(Customer_id,Customer_firstName,Customer_lastName,Customer_Address, Customer_Phone_no,Customer_Password,Customer_Email):
    cursor.execute(f"SELECT EXISTS (SELECT * FROM customer WHERE Customer_id='{Customer_id}')")
    result = cursor.fetchone()[0]
    if(result==1):
        print("Customer ID already exist")
    else:
        print("Sign up Completed")
        Order_Id=90
        Satus=0
        Product_Id=90
        # cursor.execute(f"INSERT INTO buyingmulprod (Customer_id,Product_Id) values ('{Customer_id}','{Product_Id}')") #rehta h abhi
        # con.commit()
        try:
            # print("HI") try to give 1-20
            cursor.execute(f"INSERT INTO buyingmulprod (Customer_id,Product_Id) values ('{Customer_id}','{Product_Id}')") #rehta h abhi
            cursor.execute(f"INSERT INTO customer (Customer_id,Customer_firstName,Customer_lastName,Customer_Address,Customer_Phone_no,Customer_Password,Customer_Email,Order_Id,Satus,Product_Id) VALUES ('{Customer_id}','{Customer_firstName}','{Customer_lastName}','{Customer_Address}','{Customer_Phone_no}','{Customer_Password}','{Customer_Email}','{Order_Id}','{Satus}','{Product_Id}')") 
            con.commit()
        except:
            print("Product_ID/Order_ID Not found\n")
def seecate():
    cursor.execute("SELECT * FROM category")
    db=cursor.fetchall()
    for j in db:
        print(j)
def seeproduct():
    cursor.execute("SELECT * FROM product_catalog")
    db=cursor.fetchall()
    for j in db:
        print(j)

def select_query(v):
    cursor.execute(v)
    con.commit()
    tyt=cursor.fetchall()   
    for k in tyt:
        print(k)
def all_database():
    cursor3.execute("SHOW DATABASES")
    db=cursor3.fetchall()
    for j in db:
        print(j[0])

def salebycategory():
    cursor2.execute("SELECT Product_Name, SUM(Quantity*Price) AS SALES_BY_CATEGORY FROM product_catalog GROUP BY Product_Name ORDER BY SALES_BY_CATEGORY")
    db=cursor2.fetchall()
    for j in db:
        print(j)

def del_date_dis_queries(date):
    
    cursor2.execute(f"DELETE FROM discount WHERE DATE(expiary_date)='{date}'")
    con2.commit()

def slice():
    query='''SELECT category.Category_id, product_catalog.Product_Name
    FROM category
    JOIN admin on admin.Product_id=category.Category_id
    JOIN product_catalog on product_catalog.Product_Id=category.Category_id
    WHERE Category_Name='Electrical' 
    GROUP BY Category_id
    '''
    cursor2.execute(query)
    db=cursor2.fetchall()
    for j in db:
        print(j)
def drill_through():
    query='''SELECT category.Category_id, product_catalog.Product_Name
    FROM category
    JOIN admin on admin.Product_id=category.Category_id
    JOIN product_catalog on product_catalog.Product_Id=category.Category_id
    GROUP BY Category_id
    '''
    cursor2.execute(query)
    db=cursor2.fetchall()
    for j in db:
        print(j)
            
def ROLLUP():
    cursor2.execute('''SELECT product_catalog.Product_Name, SUM(Quantity*Price) AS SALES_BY_CATEGORY 
    FROM product_catalog 
    JOIN category ON category.Category_id=product_catalog.Product_Id
    GROUP BY Product_Name WITH ROLLUP''')
    db=cursor2.fetchall()
    for j in db:
        print(j)  

def buyprod(Customer_id,Product_ID):
    quan=0
    cursor.execute(f"SELECT EXISTS (SELECT * FROM product_catalog WHERE Product_ID='{Product_ID}' and Quantity >'{quan}')")
    result = cursor.fetchone()[0]
    if(result==1):
        cursor.execute(f"insert into buyingmulprod (Customer_id,Product_ID) values ('{Customer_id}','{Product_ID}')")
        cursor.execute(f"update product_catalog set Quantity=Quantity-1 where Product_ID='{Product_ID}'")
        print("product purchased!\n")
        con.commit()
    else:
        print("Stock is finished OR product_ID is wrong\n")

def cartfun(Product_ID,Quantity,Customer_id):
    # cursor.execute("START TRANSACTIONS")
    cursor.execute(f"SELECT EXISTS (SELECT * FROM product_catalog WHERE Product_Id='{Product_ID}')")
    result = cursor.fetchone()[0]
    if(result==1):
        cursor.execute(f"select Price from product_catalog where Product_Id='{Product_ID}'")
        db=cursor.fetchall()
        for j in db:    # read only Transactions. and Read write Transactions.
            my_int=int(j[0])
            quan=my_int*Quantity
            cursor.execute(f"insert into Cart (Total_Price,Total_Quantity,Product_Id,Customer_Id) values ('{quan}','{Quantity}','{Customer_id}','{Customer_id}')")
            con.commit()
            print("Added to Cart\n")
    else:
        print("Product_ID not found!!\n")

def bill(Payment_Mode,Customer_id):
    cursor.execute(f"SELECT EXISTS (SELECT * FROM buyingmulprod WHERE Customer_id='{Customer_id}')")
    result = cursor.fetchone()[0]
    if(result==1):
        Amount=0
        quan=0
        cursor.execute(f"select Product_Id from buyingmulprod where Customer_id='{Customer_id}'")
        db=cursor.fetchall()
        for id in db:
           proid=int(id[0])
           cursor.execute(f"Select Price from product_catalog where Product_Id='{proid}'")
           fg=cursor.fetchall()
           for amt in fg:
               intamt=int(amt[0])
               quan+=1
               Amount+=intamt

        print("The Total Amount is:",Amount)
        cursor.execute(f"SELECT EXISTS (SELECT * FROM bill WHERE Bill_Id='{Customer_id}')")
        ult=cursor.fetchone()[0]
        # print("cond\n")
        if(ult==1):
            # print("yes_ult\n")
            cursor.execute(f"UPDATE bill set Amount='{Amount}',Payment_Mode='{Payment_Mode}' where Bill_Id='{Customer_id}'")
            print("Bill Updated")
            con.commit()
        else:
            # print("ult\n")
            cursor.execute(f"INSERT INTO bill (Bill_Id,Amount,Payment_Mode) values('{Customer_id}','{Amount}','{Payment_Mode}')")
            con.commit()
        
        cursor.execute(f"SELECT EXISTS (SELECT * FROM orders WHERE Order_Id='{Customer_id}')")
        olt=cursor.fetchone()[0]
        if(olt==1):
            cursor.execute(f"UPDATE orders set Order_Id='{Customer_id}',No_of_products='{quan}',Bill_Id='{Customer_id}' where Order_Id='{Customer_id}'")
            cursor.execute(f"update customer set Order_Id='{Customer_id}' where Customer_id='{Customer_id}'")
            con.commit()
        else:
            discount_percen= random.randint(44, 49)
            cursor.execute(f"INSERT INTO orders (Order_Id,No_of_products,Copoun_Code,Bill_Id) values('{Customer_id}','{quan}','{discount_percen}','{Customer_id}')")
            cursor.execute(f"update customer set Order_Id='{Customer_id}' where Customer_id='{Customer_id}'")
            con.commit()

    else:
        print("Nothing Purchased by Customer having ID " ,Customer_id)


def delivery(Delivery_ID, Deliveryman_Name):
    cursor.execute(f"SELECT EXISTS (SELECT * FROM delivery_men WHERE Delivery_ID='{Delivery_ID}' and Deliveryman_Name='{Deliveryman_Name}')")
    olt=cursor.fetchone()[0]
    if(olt==1):
        print("Change the Status of Customer")
        Customer_id=int(input("Enter the Customer Id:"))
        cursor.execute(f"SELECT EXISTS (SELECT * FROM orders WHERE Order_Id='{Customer_id}')")
        result=cursor.fetchone()[0]
        Satus=int(input("enter Status 0/1:"))
        if(result==1):
            cursor.execute(f"update customer set Satus='{Satus}' where Customer_id='{Customer_id}'")
            con.commit()
            # as order_Id associated with customer_id
            cursor.execute(f"update delivery_men set Order_Id='{Customer_id}' where Delivery_ID='{Delivery_ID}'")
            con.commit()
        else:
            print("Customer Doest Not exist:\n")


    else:
        print("NO delivery Man has Id and Name",Delivery_ID,Deliveryman_Name)

    


while(True):
    print("                    ONLINE RETAIL SYSTEM")
    print("-------------------------------------------------------------")
    print("*************************************************************")
    print("1) SIGNUP as Admin/Seller")
    print("2) LOGIN as Admin/Seller")
    print("3) SIGNUP as Customer")
    print("4) LOGIN as Customer")
    print("5) Developer Option")
    print("6) Delivery Man")
    print("7) Exit")
    a=int(input("Enter the Choice: "))
    if(a==1):
        print("*******Enter the Details***********")
        Admin_ID=int(input(("Enter the Admin_ID:")))
        UserName=input(("Enter the UserName:"))
        Password=input(("Enter the Password:"))
        Category_id=int(input(("Enter the Category_id:")))  # need to know which category he wants to acess CAtegory_id and pro_id and delivry_id
        Product_id=int(input(("Enter the Product_id:")))  
        Delivery_ID=int(input(("Enter the Delivery_ID:")))
        signupAdmin(Admin_ID,UserName,Password,Category_id,Product_id,Delivery_ID)
    if(a==2):
        print("*******Enter the Details***********")
        Admin_ID=int(input("Enter the Admin_ID:"))
        Password=input("Enter the password:")
        cursor.execute(f"SELECT EXISTS (SELECT * FROM admin WHERE Admin_ID = '{Admin_ID}' and Password='{Password}');")
        result = cursor.fetchone()[0]
        if(result==1):
                while(1):
                    print("Welcome back sir!")
                    print("***************************")
                    print("1) Add Category")
                    print("2) Add Product")
                    print("3) Assign delivery Man")
                    print("4) exit")
                    choice=int(input("Enter the choice:"))
                    if(choice==1): # add in the category table
                        Category_id=int(input("Enter the Category_id:"))
                        Category_Name=(input("Enter the Category_Name:"))
                        Description=input("Enter the Description:")
                        addcategory(Category_id,Category_Name,Description)

                    if(choice==2):
                        Product_id=int(input("Enter the Produt id:"))
                        Product_Name=input("Enter the Product Name:")
                        Description=input("Enter the Description:")
                        Quantity=int(input('Enter the Quantity:'))
                        Price=int(input("Enter the Price:"))
                        addproduct(Product_id,Product_Name,Description,Quantity,Price)

                    
                    if(choice==3):
                        Delivery_ID=int(input("Enter the delivery_id:"))
                        Deliveryman_Name=input("Enter the Name:")
                        Order_Id=int(input("Enter the Order_Id:"))
                        adddelivery(Delivery_ID,Deliveryman_Name,Order_Id)
                    if(choice==4):
                        break
        else:
            print("Wrong Credentials")
    if(a==3):
        print("*******Enter the Details***********")
        Cutomer_id=int(input(("Enter the Customer ID:")))
        Customer_firstName=input(("Enter the FirstName:"))
        Customer_lastName=input(("Enter the LastName:"))
        Customer_Address=input("Enter the Address:")
        Customer_Phone_no=int(input(("Enter the Phone Number:")))  
        Customer_Password=input("Enter the Password:")
        Customer_Email=input("Enter the Email:") #try to give 1-20
        signupCustomer(Cutomer_id,Customer_firstName,Customer_lastName,Customer_Address, Customer_Phone_no,Customer_Password,Customer_Email)

    if(a==4):
        print("*******Enter the Details***********")
        Customer_id=int(input(("Enter the Customer ID:")))
        Customer_Password=input("Enter the Password:")
        cursor.execute(f"SELECT EXISTS (SELECT * FROM customer WHERE  Customer_id= '{Customer_id}' and Customer_Password='{Customer_Password}');")
        result = cursor.fetchone()[0]
        if(result==1):
            while(1):
                print("Welcome back sir")
                print("*******************************")
                print("1) Buy a Product")
                print("2) Add to Cart")
                print("3) See all categories")
                print("4) See all Products")
                print("5) Bill of the Customer")
                print("6) Exit")
                #abhi aur ghusaane hai isme.
                choice=int(input("Enter the Choice:"))
                if(choice==1):
                    Product_ID=int(input("Enter the Product ID want to buy:"))
                    buyprod(Customer_id,Product_ID)

                if(choice==3):
                    seecate()
                if(choice==4):
                    seeproduct()
                if(choice==6):
                    break
                if(choice==2):
                    
                    Product_ID=int(input("Enter the Product ID want to add in cart:"))
                    Quantity=int(input("Enter the Quantity:"))
                    cartfun(Product_ID,Quantity,Customer_id)
                if(choice==5):
                    Payment_Mode=input("Enter the Payment Mode:")
                    bill(Payment_Mode,Customer_id)




        else:
            print("Wrong Credentials")
    
    if(a==7):
        cursor2.close()
        cursor.close()
        con.close()
        con2.close()
        break
    if(a==6):
        Delivery_ID=int(input(("Enter the Delivery ID:")))
        Deliveryman_Name=input("Enter the Deliveryman Name:")
        delivery(Delivery_ID, Deliveryman_Name)

    if(a==5):  
                                                     # DEVELOPER OPTION
        print("Welcome to Developer option")
        print("1) Embedded queries")
        print("2) OLAP Queries")
        print("3) Triggers")
        print("4) exit")
        n=int(input("Enter the Choice:"))
        if(n==1):
            while(1):
                print("1) show all databases")
                print("2) show Tables")
                print("3) exit")
                a=int(input("choice:"))
                if(a==1):
                    all_database()
                if(a==2):
                    v=input("Enter Query:")
                    select_query(v)
                if(a==3):
                    break
        if(n==4):
            break
        if(n==2):
            while(1):
                print("1)Sales by Product")
                print("2) Slice OLAP(when category is electrical and find pro_name,category_id)")
                print("3) Drill through(when category can be anything and find pro_name,category_id)  ")
                print("4) ROLL UP ")
                print("5)Exit")
                m=int(input("Enter the Choice:"))
                if(m==1):
                    salebycategory()
                if(m==2):
                    slice()
                if(m==3):
                    drill_through()
                if(m==4):
                    ROLLUP()
                if(m==5):
                    break
        if(n==3):
            print("1) expired Discount(TRIGGER)")
            print("2) product that have out of quantity")
            print("3)exit")
            f=int(input("Enter the choice:"))
            if(f==1):
                date=input("Enter the Date(yy-mm-dd):")
                del_date_dis_queries(date)
                select_query("SELECT * FROM backup_discount")
            if(f==2):
                    print("Updating data")
                    amount=int(input("ENter the Amount:")) # if less than 9 u will find out its significance.
                    Billid=int(input("Enter the Bill ID:")) 
                    select_query(f"UPDATE bill SET Amount='{amount}' WHERE Bill_Id='{Billid}'")
                    # select_query(f"SELECT * FROM bill")
            if(f==3):
                break
