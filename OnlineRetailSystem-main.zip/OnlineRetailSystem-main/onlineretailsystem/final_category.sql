-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: final
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `Category_id` int NOT NULL,
  `Category_Name` varchar(100) NOT NULL,
  `Description` text,
  PRIMARY KEY (`Category_id`),
  KEY `cateid_idx` (`Category_id`),
  CONSTRAINT `fk1_category_productcatalog` FOREIGN KEY (`Category_id`) REFERENCES `product_catalog` (`Product_Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'GROCERY','GREAT'),(2,'Grocery','NICE'),(3,'Electrical','NICE'),(4,'Grocery','NICE'),(5,'Electrical','NICE'),(6,'Grocery','NICE'),(7,'Electrical','NICE'),(8,'Grocery','NICE'),(9,'Electrical','NICE'),(10,'Grocery','NICE'),(11,'Electrical','NICE'),(12,'Grocery','NICE'),(13,'Electrical','NICE'),(14,'Grocery','NICE'),(15,'Electrical','NICE'),(16,'Grocery','NICE'),(17,'Electrical','NICE'),(18,'Grocery','NICE'),(19,'Electrical','NICE'),(20,'Grocery','NICE'),(21,'Electrical','NICE'),(22,'Grocery','NICE'),(23,'Electrical','NICE'),(24,'Grocery','NICE'),(25,'Electrical','NICE'),(26,'Grocery','NICE'),(27,'Electrical','NICE'),(28,'Grocery','NICE'),(29,'Electrical','NICE'),(30,'Grocery','NICE'),(31,'Electrical','NICE'),(32,'Grocery','NICE'),(33,'Electrical','NICE'),(34,'Grocery','NICE'),(35,'Electrical','NICE'),(36,'Grocery','NICE'),(37,'Electrical','NICE'),(38,'Grocery','NICE'),(39,'Electrical','NICE'),(40,'Grocery','NICE'),(41,'Electrical','NICE'),(42,'Grocery','NICE'),(43,'Electrical','NICE'),(44,'Grocery','NICE'),(45,'Electrical','NICE'),(46,'Grocery','NICE'),(47,'Electrical','NICE'),(48,'Grocery','NICE'),(49,'Electrical','NICE'),(50,'Grocery','NICE'),(51,'Electrical','NICE'),(52,'Grocery','NICE'),(53,'Electrical','NICE'),(54,'Grocery','NICE'),(55,'Electrical','NICE'),(56,'Grocery','NICE'),(57,'Electrical','NICE'),(58,'Grocery','NICE'),(59,'Electrical','NICE'),(60,'Grocery','NICE'),(61,'Electrical','NICE'),(62,'Grocery','NICE'),(63,'Electrical','NICE'),(64,'Grocery','NICE'),(65,'Electrical','NICE'),(66,'Grocery','NICE'),(67,'Electrical','NICE'),(68,'Grocery','NICE'),(69,'Electrical','NICE'),(70,'Grocery','NICE'),(71,'Electrical','NICE'),(72,'Grocery','NICE'),(73,'Electrical','NICE'),(74,'Grocery','NICE'),(75,'Electrical','NICE'),(76,'Grocery','NICE'),(77,'Electrical','NICE'),(78,'Grocery','NICE'),(79,'Electrical','NICE'),(80,'Grocery','NICE'),(81,'Electrical','NICE'),(82,'Grocery','NICE'),(83,'Electrical','NICE'),(84,'Grocery','NICE'),(85,'Electrical','NICE'),(86,'Grocery','NICE'),(87,'Electrical','NICE'),(88,'Grocery','NICE'),(89,'Electrical','NICE'),(90,'Grocery','NICE'),(91,'Electrical','NICE'),(92,'Grocery','NICE'),(93,'Electrical','NICE'),(94,'Grocery','NICE'),(95,'Electrical','NICE'),(96,'Grocery','NICE'),(97,'Electrical','NICE'),(98,'Grocery','NICE'),(99,'Electrical','NICE'),(100,'Grocery','NICE'),(102,'Menwear','opo');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-24 18:27:37
